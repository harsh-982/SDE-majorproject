import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { Users } from "./Users";
import { Injectable } from "@angular/core";

@Injectable({
    providedIn:'root'
})
export class UsersService{
    private baseUrl='http://localhost:8081/auth';
    constructor(private http: HttpClient){

    }
    addUsers(user:Users): Observable<Users>{
        return this.http.post<Users>(`${this.baseUrl}/register`,user)
    }
    login(user:Users): Observable<{jwtToken: string}>{
         return this.http.post<{jwtToken:string}>(`${this.baseUrl}/login`,user);
    }
}