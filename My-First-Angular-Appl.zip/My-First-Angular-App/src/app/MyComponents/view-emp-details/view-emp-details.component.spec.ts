import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewEmpDetailsComponent } from './view-emp-details.component';

describe('ViewEmpDetailsComponent', () => {
  let component: ViewEmpDetailsComponent;
  let fixture: ComponentFixture<ViewEmpDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewEmpDetailsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewEmpDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
