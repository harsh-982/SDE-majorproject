import { Component } from '@angular/core';
import { EmployeeService } from '../../EmployeeService';
import { NavbarComponent } from "../navbar/navbar.component";
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-view-emp-details',
  standalone: true,
  imports: [NavbarComponent],
  templateUrl: './view-emp-details.component.html',
  styleUrl: './view-emp-details.component.css'
})
export class ViewEmpDetailsComponent {
  employee:any;
  id!: any;
  constructor(private employeeData:EmployeeService,private route:ActivatedRoute){
  }
  ngOnInit():void{
    this.id=this.route.snapshot.paramMap.get('id');
    this.viewEmployeeDetails(this.id);
  }
  viewEmployeeDetails(id:number):void {
    this.employeeData.getEmployeeById(id).subscribe(
      (response)=>{
        console.log(response);
        this.employee=response;
      }
    );
    }

}
