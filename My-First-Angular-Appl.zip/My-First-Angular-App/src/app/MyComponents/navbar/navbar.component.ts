import { Component, EventEmitter, Output } from '@angular/core';
import { EmployeeService } from '../../EmployeeService';
import { Employee } from '../../Employee';
import { HomePageComponent } from "../home-page/home-page.component";
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [HomePageComponent,FormsModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {
  searchedEmployees:Employee[]=[];
  seachValue!:string;
  @Output() searchResults=new EventEmitter<Employee[]>();
  constructor(private employeeData:EmployeeService, private router:Router){
  }
  logout() {
    localStorage.removeItem('token');
    this.router.navigate([''])
    }
search(){
  // event.preventDefault();
  if(this.seachValue){
    this.employeeData.searchEmployee(this.seachValue).subscribe(data=>{
      console.log(data);
      this.searchedEmployees=data;
      this.searchResults.emit(this.searchedEmployees);
    })
  }else{
    this.searchResults.emit([]);
  }
}
}
