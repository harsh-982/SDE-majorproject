import { Component } from '@angular/core';
import { NavbarComponent } from "../navbar/navbar.component";
import { EmployeeService } from '../../EmployeeService';
import { Router } from '@angular/router';
import { Employee } from '../../Employee';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-add-emp',
  standalone: true,
  imports: [NavbarComponent,FormsModule],
  templateUrl: './add-emp.component.html',
  styleUrl: './add-emp.component.css'
})
export class AddEmpComponent {
  emp: Employee={name:'',email:''};
  constructor(private employeeService:EmployeeService, private router:Router){

  }
  ngOnInit():void{

  }
  onSubmit():void{
    this.employeeService.addEmployee(this.emp).subscribe(
      response=>{
        alert('Employee Added successfully.');
        console.log('Employee added',response);
      }
    );
  }

}
