import { Component } from '@angular/core';
import { UsersService} from '../../UsersService';
import { Users } from '../../Users';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-up',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './sign-up.component.html',
  styleUrl: './sign-up.component.css',
})
export class SignUpComponent {
  user: Users={username:'',password:'',role:''};
  constructor(private usersService: UsersService, private router:Router){

  }
  ngOnInit():void{

  }
  onSubmit():void{
    this.usersService.addUsers(this.user).subscribe(
      response=>{
        alert('User registered successfully.');
        console.log('User added',response);

      }
    );
  }
  onLogin():void{
    this.usersService.login(this.user).subscribe(
      response=>{
        if(response.jwtToken){
          localStorage.setItem('token',response.jwtToken);
          this.router.navigate(['/home']);
        }else{
          alert("Login failed");
        }
      });
  }

}
