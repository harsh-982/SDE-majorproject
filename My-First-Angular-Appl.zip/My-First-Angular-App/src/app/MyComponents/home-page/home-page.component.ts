import { Component, Input } from '@angular/core';
import { EmployeeService } from '../../EmployeeService';
import { response } from 'express';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { NavbarComponent } from "../navbar/navbar.component";
import { Employee } from '../../Employee';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-home-page',
  standalone: true,
  imports: [CommonModule, NavbarComponent,FormsModule],
  templateUrl: './home-page.component.html',
  styleUrl: './home-page.component.css',
  preserveWhitespaces: true
})
export class HomePageComponent {
  employees:any[]=[];
  employee:any;
  pageNumber: number=0;
  pageSize: number=5;
  sortBy: string='id';
  sortDir: string='asc';
  totalPages!: number;
  totalElements!: number;
  lastPage!: boolean;
  constructor(private employeeData:EmployeeService, private router:Router){
  }
  ngOnInit():void{
    this.getEmployees();
  }
  getEmployees():void{
    this.employeeData.getEmployees(this.pageNumber,this.pageSize,this.sortBy,this.sortDir).subscribe(
      (response)=>{
        console.log(response);
        this.employees=response.content;
        this.totalPages=response.totalPages;
        this.totalElements=response.totalElements;
        this.lastPage=response.lastPage;
      }
    );
  }
  getPaginationArray():number[]{
    return Array(this.totalPages).fill(0).map((_,i)=>i);
  }
  changePage(newPageNumber:number){
    if(newPageNumber>=0 && newPageNumber<this.totalPages){
      console.log(newPageNumber)
      this.pageNumber=newPageNumber;
      this.getEmployees();
    }
  }
  onSearchResults(searchedEmployee:Employee[]){
   if(searchedEmployee.length===0){
    this.getEmployees();
   }else{
     this.employees=searchedEmployee;
   }

  }
  deleteEmployee(id:number):void {
    if(confirm('Are you sure you want to delete this employee details?')){
      this.employeeData.deleteEmployee(id).subscribe(
        ()=>{
           this.employees=this.employees.filter(employee=>employee.id!==id);
           
          this.router.navigate(['/home']);
          this.getEmployees();
        }
      );
    }
    };
    renderToViewEmpDetails(id:number):void {
          this.router.navigate(['/employee',id]);
      }
      renderToEditEmpDetails(id:number):void {
        this.router.navigate(['/editEmployee',id]);
        }
}
