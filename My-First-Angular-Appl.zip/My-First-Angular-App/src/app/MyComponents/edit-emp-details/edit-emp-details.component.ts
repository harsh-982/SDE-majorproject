import { Component } from '@angular/core';
import { NavbarComponent } from "../navbar/navbar.component";
import { EmployeeService } from '../../EmployeeService';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Employee } from '../../Employee';

@Component({
  selector: 'app-edit-emp-details',
  standalone: true,
  imports: [NavbarComponent,FormsModule],
  templateUrl: './edit-emp-details.component.html',
  styleUrl: './edit-emp-details.component.css'
})
export class EditEmpDetailsComponent {
  employee:any;
  id!: any;
  constructor(private employeeData:EmployeeService,private route:ActivatedRoute,private router:Router){
  }
  ngOnInit():void{
    this.id=this.route.snapshot.paramMap.get('id');
    this.getEmployeeDetails(this.id);
  }
  getEmployeeDetails(id:number):void {
    this.employeeData.getEmployeeById(id).subscribe(
      (response)=>{
        console.log(response);
        this.employee=response;
      }
    );
    }
    editEmployeeDetails():void {
      this.id=this.route.snapshot.paramMap.get('id');
      this.employeeData.updateEmployee(this.id,this.employee).subscribe(
        (response)=>{
          console.log(response);
           this.router.navigate(['/home']);
        }
      );
      }

}
