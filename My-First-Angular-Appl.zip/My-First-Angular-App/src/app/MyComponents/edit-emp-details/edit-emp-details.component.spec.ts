import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditEmpDetailsComponent } from './edit-emp-details.component';

describe('EditEmpDetailsComponent', () => {
  let component: EditEmpDetailsComponent;
  let fixture: ComponentFixture<EditEmpDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EditEmpDetailsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditEmpDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
