export interface Employee{
    name:string;
    email:string;
}   