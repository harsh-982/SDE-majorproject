export interface Users{
    username:string;
    password:string;
    role:string;
}