import { Routes } from '@angular/router';
import { HomePageComponent } from './MyComponents/home-page/home-page.component';
import { SignUpComponent } from './MyComponents/sign-up/sign-up.component';
import { AddEmpComponent } from './MyComponents/add-emp/add-emp.component';
import { ViewEmpDetailsComponent } from './MyComponents/view-emp-details/view-emp-details.component';
import { EditEmpDetailsComponent } from './MyComponents/edit-emp-details/edit-emp-details.component';

export const routes: Routes = [
    {path:'employee/:id',component:ViewEmpDetailsComponent},
    {path:'editEmployee/:id',component:EditEmpDetailsComponent},
    {path:'home',component:HomePageComponent},
    {path:'addEmployee',component:AddEmpComponent},
    {path:'',component:SignUpComponent}
];
