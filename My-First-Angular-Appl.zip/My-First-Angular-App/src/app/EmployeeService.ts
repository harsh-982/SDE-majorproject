import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Observable } from "rxjs";
import { Employee } from "./Employee";

@Injectable({
    providedIn:'root'
})
export class EmployeeService{
    private baseUrlForUser='http://localhost:8081/User';
    private baseUrlForAdmin='http://localhost:8081/Admin';
    constructor(private http: HttpClient){

    }
    getEmployees(pageNumber: number, pageSize: number, sortBy: string, sortDir: string): Observable<any>{
        const token=localStorage.getItem('token');
        const headers=new HttpHeaders({'Authorization': `Bearer ${token}`});
        let params=new HttpParams()
        .set('pageNumber',pageNumber.toString())
        .set('pageSize',pageSize.toString())
        .set('sortBy',sortBy)
        .set('sortDir',sortDir);
        console.log(params.toString())
            return this.http.get<any>(`${this.baseUrlForUser}/getAllEmployees`,{headers,params});
        }
// getEmployees(): Observable<any>{
//     const token=localStorage.getItem('token');
//     const headers=new HttpHeaders({'Authorization': `Bearer ${token}`});
//         return this.http.get<any>(`${this.baseUrl}/getAllEmployees`,{headers});
//     }
    getEmployeeById(id:number): Observable<any>{
        const token=localStorage.getItem('token');
        const headers=new HttpHeaders({'Authorization': `Bearer ${token}`});
            return this.http.get<any>(`${this.baseUrlForAdmin}/getEmployee/${id}`,{headers});
        }
    addEmployee(employee:Employee): Observable<Employee>{
        const token=localStorage.getItem('token');
        const headers=new HttpHeaders({'Authorization': `Bearer ${token}`});
        return this.http.post<Employee>(`${this.baseUrlForUser}/addEmployee`,employee,{headers})
    }
    deleteEmployee(id:number):Observable<void>{
        const token=localStorage.getItem('token');
        const headers=new HttpHeaders({'Authorization': `Bearer ${token}`});
        return this.http.delete<void>(`${this.baseUrlForAdmin}/deleteEmployee/${id}`,{headers})
    }
    updateEmployee(id:number,employee:Employee):Observable<void>{
        const token=localStorage.getItem('token');
        const headers=new HttpHeaders({'Authorization': `Bearer ${token}`});
        return this.http.put<void>(`${this.baseUrlForAdmin}/updateEmployee/${id}`,employee,{headers})
    }
    searchEmployee(seachValue:string):Observable<Employee[]>{
        const token=localStorage.getItem('token');
        const headers=new HttpHeaders({'Authorization': `Bearer ${token}`});
        const id=!isNaN(Number(seachValue));
        let params=new HttpParams();
        if(id){
            params=params.set('id',seachValue);
        }else{
            params=params.set('keyword',seachValue);
        }
        return this.http.get<Employee[]>(`${this.baseUrlForUser}/getEmployees/search`,{headers,params})
    }

}
